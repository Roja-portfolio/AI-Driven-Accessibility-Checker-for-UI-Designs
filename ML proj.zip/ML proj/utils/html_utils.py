# utils/html_utils.py

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from PIL import Image
import io
import os

def generate_pdf_report(img_path, contrast_score, alt_text_score, resize_score, rule_score, ml_score, suggestions):
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # Title
    c.setFont("Helvetica-Bold", 16)
    c.drawString(72, height - 72, "Accessibility Evaluation Report")

    # Add uploaded image
    if os.path.exists(img_path):
        img = Image.open(img_path)
        img.thumbnail((400, 300))
        image_reader = ImageReader(img)
        c.drawImage(image_reader, 72, height - 400)

    # Scores
    c.setFont("Helvetica", 12)
    text_start = height - 420
    c.drawString(72, text_start, f"Contrast Score: {contrast_score:.2f}/100")
    c.drawString(72, text_start - 20, f"Alt Text Score: {alt_text_score}/100")
    c.drawString(72, text_start - 40, f"Text Resize Score: {resize_score}/100")
    c.drawString(72, text_start - 60, f"Final Score (Rule-Based): {rule_score:.2f}/100")
    c.drawString(72, text_start - 80, f"Final Score (ML-Predicted): {ml_score:.2f}/100")

    # Suggestions
    c.setFont("Helvetica-Bold", 12)
    c.drawString(72, text_start - 120, "Suggestions for Improvement:")
    c.setFont("Helvetica", 11)
    for i, s in enumerate(suggestions):
        c.drawString(90, text_start - 140 - i * 18, f"- {s}")

    c.save()
    buffer.seek(0)
    return buffer
