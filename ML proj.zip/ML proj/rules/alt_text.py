import os

def check_alt_text(img_path):
    """
    Placeholder alt-text logic for screenshots.
    If image filename contains 'alt' or 'desc', assume it's present.
    """
    fname = os.path.basename(img_path).lower()
    if 'alt' in fname or 'desc' in fname:
        return 100
    return 0
