# rules.py
from PIL import Image

def check_contrast_simple(img_path):
    # Placeholder: Replace with real contrast logic
    return {"contrast": 3.2}

def check_use_of_color(img_path):
    # Placeholder: 1 = passed, 0 = failed
    return {"color": 1}

def check_text_resize(img_path):
    return {"text_resize": 1}

def check_alt_text(img_path):
    # Placeholder: 1 = present, 0 = missing
    return {"alt_text": 0}
