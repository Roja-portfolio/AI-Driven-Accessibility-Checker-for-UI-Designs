# scoring.py

def compute_score(results):
    contrast = results.get("contrast", 0)
    color = results.get("color", 0)
    text_resize = results.get("text_resize", 0)
    alt_text = results.get("alt_text", 0)

    score = 0

    if contrast >= 4.5:
        score += 25
    if color == 1:
        score += 25
    if text_resize == 1:
        score += 25
    if alt_text == 1:
        score += 25

    return score
