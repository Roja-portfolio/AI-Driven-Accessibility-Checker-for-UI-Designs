from PIL import Image
import numpy as np

def check_contrast_ratio(img_path):
    try:
        image = Image.open(img_path).convert("L")  # Convert to grayscale
        np_img = np.array(image)

        light = np.percentile(np_img, 95)  # Simulated foreground
        dark = np.percentile(np_img, 5)    # Simulated background

        # Normalize to [0,1]
        L1 = max(light, dark) / 255
        L2 = min(light, dark) / 255

        # WCAG contrast formula
        ratio = (L1 + 0.05) / (L2 + 0.05)
        score = min(100, round((ratio / 21) * 100, 2))  # Scale to 0–100

        return score
    except:
        return 0
