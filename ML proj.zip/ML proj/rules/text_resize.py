from PIL import Image

def check_text_resize(img_path):
    """
    Simple simulation: check if image can be resized and still readable.
    Placeholder: return 100 if resize doesn't fail.
    """
    try:
        image = Image.open(img_path)
        resized = image.resize((int(image.width * 1.5), int(image.height * 1.5)))
        return 100
    except:
        return 0
