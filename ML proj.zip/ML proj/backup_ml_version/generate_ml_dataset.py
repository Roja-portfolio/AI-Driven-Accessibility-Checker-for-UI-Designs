import os
import csv
from rules.scoring import compute_rule_score  # Your scoring function
from pathlib import Path

# Set paths
IMAGE_FOLDER = Path("datasets/unique_uis")
OUTPUT_CSV = Path("datasets/rule_labeled_dataset.csv")

# List to store filename and score
results = []

# Make sure the folder exists
if not IMAGE_FOLDER.exists():
    print(f"❌ Folder not found: {IMAGE_FOLDER.resolve()}")
    exit()

# Loop through all .png images
for filename in os.listdir(IMAGE_FOLDER):
    if filename.lower().endswith(".png"):
        img_path = IMAGE_FOLDER / filename
        try:
            score = compute_rule_score(str(img_path))
            results.append([filename, score])
            print(f"✅ Processed {filename} → Score: {score}")
        except Exception as e:
            print(f"⚠️ Error processing {filename}: {e}")

# Write to CSV
with open(OUTPUT_CSV, mode="w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["filename", "accessibility_score"])
    writer.writerows(results)

print(f"\n✅ Dataset saved to: {OUTPUT_CSV.resolve()}")
