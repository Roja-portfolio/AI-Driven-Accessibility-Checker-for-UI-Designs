import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
import joblib
from PIL import Image
import os

# 👇 Absolute path to project directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_DIR = os.path.join(BASE_DIR, "..", "datasets")

# Load CSV
csv_path = os.path.join(DATASET_DIR, "rule_labeled_dataset.csv")
df = pd.read_csv(csv_path)

# Feature extraction
def extract_features(image_path):
    img = Image.open(image_path).convert("L").resize((128, 128))
    return np.array(img).flatten() / 255.0

X = []
y = []

# Loop over each image
for _, row in df.iterrows():
    image_name = row["image_name"]
    image_path = os.path.join(DATASET_DIR, image_name)

    if os.path.exists(image_path):
        features = extract_features(image_path)
        X.append(features)
        y.append(row["final_score"])
    else:
        print(f"⚠️ Image not found: {image_path}")

X = np.array(X)
y = np.array(y)

# Train model
if len(X) > 0:
    model = LinearRegression()
    model.fit(X, y)

    # Save model to backup_ml_version/
    model_path = os.path.join(BASE_DIR, "ml_model.pkl")
    joblib.dump(model, model_path)
    print("✅ Model trained and saved!")
else:
    print("❌ No valid training data found. Model not trained.")
