import joblib
import numpy as np
from PIL import Image

def extract_features(image_path):
    image = Image.open(image_path).convert("L").resize((128, 128))
    flat = np.array(image).flatten() / 255.0
    return flat

def predict_score(image_path):
    model = joblib.load("backup_ml_version/ml_model.pkl")
    features = extract_features(image_path).reshape(1, -1)
    score = model.predict(features)[0]
    return round(score, 2)
